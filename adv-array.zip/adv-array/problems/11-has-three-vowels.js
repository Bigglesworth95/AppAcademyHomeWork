/*
Write a function `hasThreeVowels` that accepts a string as an argument.
The function should return a boolean indicating whether or not the string
contains at least three different vowels.

Solve this using Array's `forEach()`, `map()`, `filter()` **OR** `reduce()`
methods.

Examples:

console.log(hasThreeVowels('delicious'));       //  true
console.log(hasThreeVowels('bootcamp prep'));   //  true
console.log(hasThreeVowels('bootcamp'));        //  false
console.log(hasThreeVowels('dog'));             //  false
console.log(hasThreeVowels('go home'));         //  false

*/

function drop(str, letter) {
    arr = str.split("")
    newArr = arr.map(function (char, i){
        if (char == letter) {
            return arr.splice(0, i) + arr.splice(i+1)
        }
    })
    return newArr.join("")
}

let hasThreeVowels = function(string) {
    // Your code here
    let vowels = 'aeiou';
    let count = string.split("").reduce(function(accum, letter) {
        if (vowels.includes(letter)) {
            accum += 1;
            vowels = drop(vowels, letter);
        }
        return accum;
    }, 0)
    return count >= 3;
};

console.log(hasThreeVowels('delicious'));       //  true
console.log(hasThreeVowels('bootcamp prep'));   //  true
console.log(hasThreeVowels('bootcamp'));        //  false
console.log(hasThreeVowels('dog'));             //  false
console.log(hasThreeVowels('go home'));         //  false

// Your code here

/**************DO NOT MODIFY ANYTHING UNDER THIS  LINE*****************/

try {
    module.exports = hasThreeVowels;
} catch (e) {
    module.exports = null;
}
